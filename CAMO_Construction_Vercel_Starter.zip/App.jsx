export default function CamoConstructionWebsite() {
  return (
    <div className="min-h-screen bg-[#111111] text-white font-sans">
      <section
        className="relative bg-cover bg-center min-h-[90vh] flex items-center"
        style={{
          backgroundImage:
            "linear-gradient(rgba(0,0,0,0.82), rgba(0,0,0,0.9)), url('/mnt/data/image.png')",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-block border border-[#8B7D52] px-6 py-3 rounded-full text-sm tracking-[0.25em] uppercase mb-6 bg-black/60 shadow-xl">
              Built on Experience. Built on Quality.
            </div>

            <h1 className="text-6xl md:text-8xl font-black leading-tight mb-6 drop-shadow-2xl">
              <span className="text-[#A18C5D]">CAMO</span>
              <br />
              Construction Services
            </h1>

            <p className="text-lg text-gray-300 max-w-xl leading-relaxed mb-8">
              Professional interior & exterior finishing with over 30 years of
              experience serving Parksville, Qualicum & surrounding areas.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}