# CAMO Construction Services Website

Deployment-ready starter package for:
https://camoconstructionservices.ca

## Deploy to Vercel

1. Create GitHub repository
2. Upload files
3. Import repository into Vercel
4. Add custom domain:
   camoconstructionservices.ca

## Stack
- React
- Tailwind CSS
- Vercel Hosting
